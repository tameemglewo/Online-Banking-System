function applyForCredit() {
    // Redirect to the credit card application page
    window.location.href = "credit-card-application.html";
  }